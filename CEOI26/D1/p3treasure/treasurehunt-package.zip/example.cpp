#include "treasurehuntlib.h"

#include <cstdlib>

int main() {
    // Local testing only. Remove this line before submission.
    InitFromFile("hunts.txt");

    while (true) {
        int N, K;
        NextHunt(N, K);
        if (N == -1) return 0;

        // Minimal protocol example, not an efficient solution:
        // query every cell until all K treasures have been found.
        // This is only practical for the tiny sample hunts.
        int found = 0;
        for (int y = 0; y < N && found < K; ++y) {
            for (int x = 0; x < N && found < K; ++x) {
                if (Query(x, y) == TREASURE) ++found;
            }
        }
    }
}
