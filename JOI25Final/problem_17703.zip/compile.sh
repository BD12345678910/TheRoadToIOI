#!/bin/bash
g++ -std=gnu++20 -O2 -o grader grader.cpp multi.cpp
