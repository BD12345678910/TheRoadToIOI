#include "magic.h"

std::vector<int> Amina(std::vector<int> P) {
  int N = (int)P.size();
  for (int i = 0; i < N; i++) {
    if (P[i] == i + 1) {
      P[i] = -1;
    }
  }
  return P;
}

std::vector<int> Billura(std::vector<int> Q) {
  int N = (int)Q.size();
  std::vector<int> B = Q;
  for (int i = 0; i < N; i++) {
    if (B[i] == -1) {
      B[i] = i + 1;
    }
  }
  return B;
}
